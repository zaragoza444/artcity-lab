# Art City Cinema · Delivery Package

Campaign: Kardokh & Kurdiya · Season of Homecoming
Brand: Art City
Package ID: 029038ae-de9f-49a9-af06-a7f188f6f821

Contents:
- CAMPAIGN_MANIFEST.json
- TECHNICAL_VALIDATION.json
- deliverables/ (six outputs + audio beds)
- brand/art_city_logo.svg

Ownership: Art City proprietary package.
